La tarea fue compilada y ejecutada en Windows con MinGW y WSL con el comando g++ "tarea3.cpp" -o "tarea3.exe" -Wall

La tarea consiste en 2 archivos:
    - tarea3.cpp
    - tarea3.hpp

tarea3.cpp contiene el código donde implementamos las boletas de supermercado con el hashing.
tarea3.hpp contiene el TDA del hashing.