Se compiló usando MinGW para Windows con el comando 'g++ "nombre.txt" -o nombre.exe -Wall -Wextra'
Se testeo en una VirtualBox con Ubuntu con g++ utilizando el mismo comando.
Tambien se testeo en Windows usando WSL.
