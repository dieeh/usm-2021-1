La tarea fue compilada y ejecutada en Windows con MinGW con el comando g++ "tareaX-X.cpp" -o "tareaX-X.exe" -Wall

La tarea consiste en 4 archivos:
    - tarea2-1.cpp
    - tarea2-1.hpp
    - tarea2-2.cpp
    - tarea2-2.hpp

tarea2-1 contiene el TDA polinomios implementado con listas enlazadas y el TDA listas enlazadas
tarea2-2 contiene el TDA polinomios implementado con árboles de busqueda binarios y el TDA árboles de busqueda binarios

Los separamos en 2 pares distintos, puesto que los TDA tienen distintos métodos y cada main tiene un #include distinto.